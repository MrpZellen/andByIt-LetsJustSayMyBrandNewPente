﻿using System;

namespace andByIt_LetsJustSayMyPente;

public class Game
{
    private Board board;
    private Player playerOne;
    private Player playerTwo;

    public Game()
    {
        this.board = new Board();
        this.playerOne = new Player();
        this.playerTwo = new Player();
    }
    public void startGame()
    {
        
    }

    public void endGame()
    {
        
    }

    public void printGame()
    {
        for (int i  = 0; i  < 19; i ++)
        {
            for (int j = 0; j < 19; j++)
            {
                Console.Write(board.getBoard()[i,j]);
                
            }
            Console.WriteLine("\n");
        }
    }
}