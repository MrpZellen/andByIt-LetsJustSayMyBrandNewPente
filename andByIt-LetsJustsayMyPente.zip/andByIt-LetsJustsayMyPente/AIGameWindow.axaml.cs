using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace andByIt_LetsJustSayMyPente;

public partial class AIGameWindow : Window
{
    public AIGameWindow()
    {
        InitializeComponent();
    }
}