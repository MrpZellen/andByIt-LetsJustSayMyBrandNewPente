﻿namespace andByIt_LetsJustSayMyPente;

public class Player
{
    
}